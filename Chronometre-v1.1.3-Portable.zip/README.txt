Chronomètre v1.1.3 - Portable Time Tracker
==========================================

QUICK START:
1. Run Chronometre.exe
2. Use Ctrl+Alt+F1 to start timer
3. Use Ctrl+Alt+F3 to stop and save
4. Check Chrono-log.txt for your sessions

HOTKEYS:
- Ctrl+Alt+F1: Start Timer
- Ctrl+Alt+F2: Pause/Resume Timer  
- Ctrl+Alt+F3: Stop & Save Session
- Ctrl+Alt+F4: Add Note
- Ctrl+Alt+F5: Show/Hide Overlay

REQUIREMENTS:
- Windows 10 or later
- x64 architecture
- .NET 8.0 (included)

FEATURES:
- Global hotkeys work from any application
- System tray integration
- Automatic log file creation
- Visual overlay for quick status
- No installation required

SUPPORT:
- GitHub: https://github.com/carlcgb/time-tracker
- Email: carl@vrille.io

Built with ❤️ by CGB
